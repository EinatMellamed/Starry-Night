

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StarMovement : MonoBehaviour
{
    public RaycastHit2D hit;
    public Rigidbody2D rb;

    public float farwordSpeed = 5f;
    public float rotationSpeed = 2f;
   
    public float multiplier = -1f;
    public float timer = 5f;
    public float hitWallRotation = 140;
    public float moveDitectionRange;
    


    // Start is called before the first frame update
    void Start()
    {
        rb = FindObjectOfType<Rigidbody2D>();
        timer = 5;
    }

    // Update is called once per frame
    void Update()
    {

        timer -= Time.deltaTime;
        transform.Translate(Vector3.up * farwordSpeed * Time.deltaTime);
        transform.Rotate(0, 0, rotationSpeed);

        if(timer <= 0)
        {
            Debug.Log("timesup");

            ChangeAngle();
            timer = 5;
        }

       

    }

    private void FixedUpdate()
    {

        hit = Physics2D.Raycast(transform.position, transform.TransformDirection(Vector3.up), moveDitectionRange);

        if(hit)
        {


           // Debug.Log(hit.collider.name);
           // transform.Rotate(0, 0, transform.rotation.z + hitWallRotation);

        }
        
       if   (Physics2D.Raycast(transform.position, transform.TransformDirection(Vector3.up), moveDitectionRange))
       {
            
            
         // Debug.Log("hitaWall");




        }

        

    }

    private void OnDrawGizmos()
    {

        Gizmos.color = Color.red;
        Gizmos.DrawRay(transform.position, transform.TransformDirection(Vector3.up) * moveDitectionRange);
    }


   private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.name == "hit" || collision.collider.name == "Star")
        {

            Debug.Log("Hit");


        }
        timer = 5;
      transform.Rotate(0, 0,transform.rotation.z + hitWallRotation);
       

    }

    private void OnCollisionStay2D(Collision2D collision)
    {
       if(collision.collider.name== "hit" || collision.collider.name == "Star")
        {

            Debug.Log("Hit2");


        }
        
        
    }

    private void ChangeAngle()
    {
       
        
            
            rotationSpeed = rotationSpeed * multiplier;
            



        
    }
}



